﻿namespace KingGambit.Interfaces
{
    public interface IReader
    {
        string ReadLine();
    }
}