﻿namespace KingGambit.Interfaces
{
    public interface IPerson
    {
        string Name { get; }
    }
}