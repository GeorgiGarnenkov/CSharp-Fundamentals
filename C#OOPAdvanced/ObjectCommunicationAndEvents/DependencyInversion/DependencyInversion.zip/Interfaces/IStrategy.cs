﻿namespace DependencyInversion.Interfaces
{
    public interface IStrategy
    {
        int Calculate(int firstOperand, int secondOperand);
    }
}