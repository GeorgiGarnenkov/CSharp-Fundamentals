﻿namespace DependencyInversion.Interfaces
{
    public interface IReader
    {
        string ReadLine();
    }
}