﻿namespace DependencyInversion.Interfaces
{
    public interface IWriter
    {
        void WriteLine(string line);
    }
}