﻿namespace EventImplementation.Interfaces
{
    public interface IWriter
    {
        void WriteLine(string line);
    }
}