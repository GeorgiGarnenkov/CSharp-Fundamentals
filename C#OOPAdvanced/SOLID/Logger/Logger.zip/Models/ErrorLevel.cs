﻿namespace Logger.Models
{
    public enum ErrorLevel
    {
        INFO, WARNING, ERROR, CRITICAL, FATAL
    }
}