﻿namespace CustomList
{
    public class StartUp
    {
        public static void Main()
        {
            CommandInterpreter interpreter = new CommandInterpreter();
            interpreter.Run();
        }
    }
}
