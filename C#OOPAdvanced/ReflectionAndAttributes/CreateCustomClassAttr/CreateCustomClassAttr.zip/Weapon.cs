﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

[Class("Pesho", 3, "Used for C# OOP Advanced Course - Enumerations and Attributes.", "Pesho", "Svetlio")]
public class Weapon
{
    protected Weapon()
    {

    }
}