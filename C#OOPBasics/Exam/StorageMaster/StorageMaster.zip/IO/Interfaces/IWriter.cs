﻿namespace StorageMaster.IO.Interfaces
{
    public interface IWriter
    {
        void WriteLine(string output);
    }
}