﻿namespace StorageMaster.IO.Interfaces
{
    public interface IReader
    {
        string ReadLine();
    }
}