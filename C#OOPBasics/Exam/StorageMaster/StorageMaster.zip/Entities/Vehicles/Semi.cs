﻿namespace StorageMaster.Entities.Vehicles
{
    public class Semi : Vehicle
    {
        public Semi() 
            : base(10)
        {
        }
    }
}