﻿namespace VehiclesExtension
{
    public interface IDriveEmpty
    {
        void DriveEmpty(double distance);
    }
}
