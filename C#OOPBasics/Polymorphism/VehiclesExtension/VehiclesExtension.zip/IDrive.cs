﻿namespace VehiclesExtension
{
    public interface IDrive
    {
        void Drive(double dictance);
    }
}
