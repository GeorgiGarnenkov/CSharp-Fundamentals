﻿namespace VehiclesExtension
{
    public interface IRefuel
    {
        void Refuel(double refuelAmount);
    }
}
