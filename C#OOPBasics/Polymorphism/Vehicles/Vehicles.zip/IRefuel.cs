﻿namespace Vehicles
{
    public interface IRefuel
    {
        void Refuel(double refuelAmount);
    }
}
