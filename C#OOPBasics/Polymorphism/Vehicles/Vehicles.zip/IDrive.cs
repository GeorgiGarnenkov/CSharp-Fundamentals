﻿namespace Vehicles
{
    public interface IDrive
    {
        void Drive(double dictance);
    }
}
