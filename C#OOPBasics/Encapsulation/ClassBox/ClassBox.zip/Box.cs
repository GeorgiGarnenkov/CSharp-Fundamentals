﻿public class Box
{
    private double length;
    private double width;
    private double height;

    public Box(double length, double width, double height)
    {
        this.length = length;
        this.width = width;
        this.height = height;
    }
    private double LiteralSurfaceArea()
    {
        return 2 * length * height + 2 * width * height;
    }

    private double Area()
    {
        return 2 * length * width + 2 * length * height + 2 * width * height;
    }

    private double Volume()
    {
        return length * width * height;
    }

    public override string ToString()
    {
        return $"Surface Area - {this.Area():f2}\n" +
               $"Lateral Surface Area - {this.LiteralSurfaceArea():f2}\n" +
               $"Volume - {this.Volume():f2}\n";
    }
}