﻿public interface ICallable
{
    string Calling(string num);
}