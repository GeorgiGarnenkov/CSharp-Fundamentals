﻿namespace MilitaryElite
{
    public interface IRepair
    {
        string PartName { get; }
        int HoursForWork { get; }
    }
}