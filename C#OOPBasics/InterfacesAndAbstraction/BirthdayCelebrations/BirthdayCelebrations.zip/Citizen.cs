﻿public class Citizen : Society 
{
    public Citizen(string name, string age, string id, string birthdate) 
        : base(name, age, id, birthdate)
    {
    }
}