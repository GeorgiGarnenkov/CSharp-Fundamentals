﻿public class Pet : Society
{
    public Pet(string name, string birthdate)
    : base(name, birthdate)
    {
    }
}