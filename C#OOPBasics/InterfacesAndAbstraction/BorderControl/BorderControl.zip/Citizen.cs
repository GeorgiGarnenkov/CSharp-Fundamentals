﻿public class Citizen : Society 
{
    public Citizen(string name, string age, string id) 
        : base(name, age, id)
    {
    }
}