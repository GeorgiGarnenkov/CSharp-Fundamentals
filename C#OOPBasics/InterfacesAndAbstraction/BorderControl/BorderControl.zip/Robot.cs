﻿public class Robot : Society
{
    public Robot(string model, string id) 
        : base(model, id)
    {
    }
}