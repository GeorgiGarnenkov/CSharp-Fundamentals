﻿using System;
using System.Collections.Generic;
using System.Text;

public class BankAccount
{
    private int id;
    private decimal balance;

    public int Id { get; set; }
    public decimal Balance { get; set; }
}
