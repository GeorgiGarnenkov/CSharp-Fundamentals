﻿public class GemBag
{
    private string type;
    private long quantity;

    public string Type
    {
        get => type;
        set => type = value;
    }

    public long Quantity
    {
        get => quantity;
        set => quantity = value;
    }
}
